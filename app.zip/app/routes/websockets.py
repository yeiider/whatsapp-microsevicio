from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import Dict, List

router = APIRouter()

# Conexiones activas organizadas por organización
active_connections: Dict[str, List[WebSocket]] = {}

# Conectar WebSocket
async def connect_websocket(websocket: WebSocket, organization_id: str):
    await websocket.accept()
    if organization_id not in active_connections:
        active_connections[organization_id] = []
    active_connections[organization_id].append(websocket)

# Desconectar WebSocket
def disconnect_websocket(websocket: WebSocket, organization_id: str):
    if organization_id in active_connections:
        active_connections[organization_id].remove(websocket)
        if not active_connections[organization_id]:
            del active_connections[organization_id]

# Enviar evento a todos los sockets de una organización
async def emit_event(organization_id: str, event: dict):
    connections = active_connections.get(organization_id, [])
    for connection in connections:
        await connection.send_json(event)

# Endpoint principal de WebSocket
@router.websocket("/ws/{organization_id}")
async def websocket_endpoint(websocket: WebSocket, organization_id: str):
    await connect_websocket(websocket, organization_id)
    try:
        while True:
            await websocket.receive_text()  # mantener conexión viva
    except WebSocketDisconnect:
        disconnect_websocket(websocket, organization_id)
